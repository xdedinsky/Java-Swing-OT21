package sk.stuba.fei.uim.oop.window;

import javax.swing.*;

public class myFrame {
    public myFrame() {
        JFrame frame = new JFrame();
        frame.setSize(700,700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);

        myMenu menu = new myMenu(frame);
        new myPaintingPanel(menu, frame);
    }
}
