package sk.stuba.fei.uim.oop.logic;

import sk.stuba.fei.uim.oop.stamps.House;
import sk.stuba.fei.uim.oop.stamps.Tree;
import sk.stuba.fei.uim.oop.stamps.Way;
import sk.stuba.fei.uim.oop.window.myMenu;
import sk.stuba.fei.uim.oop.window.myPaintingPanel;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class myMouseListener implements MouseListener, MouseMotionListener {
    private myMenu menu;
    private myPaintingPanel board;
    private int startingComponent;
    boolean condition;
    private Way currentWay;

    public myMouseListener(myPaintingPanel board, myMenu menu) {
        board.addMouseListener(this);
        board.addMouseMotionListener(this);
        this.menu = menu;
        this.board = board;
    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        condition = false;
        switch (menu.getMode()) {
            case 0:
                Tree tree = new Tree(e.getX()-25, e.getY()-25, 50, 50, menu.getColors().get(menu.getColor()%3));
                board.getTrees().add(tree);
                board.paintComponent(board.getGraphics());
                menu.setColor(menu.getColor()+1);
                menu.getModeLabel().setText("Mode: Tree");
                menu.getModeLabel().setForeground(menu.getColors().get(menu.getColor()%3));
                break;
            case 1:
                House house = new House(e.getX()-25, e.getY()-25, 50, 50, menu.getColors().get(menu.getColor()%3));
                board.getHouses().add(house);
                board.paintComponent(board.getGraphics());
                menu.setColor(menu.getColor()+1);
                menu.getModeLabel().setText("Mode: House");
                menu.getModeLabel().setForeground(menu.getColors().get(menu.getColor()%3));
                break;
            case 2:
                for (Tree treeTemp : board.getTrees()) {
                    if (treeTemp.isMouseOn(e.getX(), e.getY())) {
                        condition = true;
                        startingComponent = 0;
                    }
                }
                for (House houseTemp : board.getHouses()) {
                    if (houseTemp.isMouseOn(e.getX(), e.getY())) {
                        condition = true;
                        startingComponent = 1;
                    }
                }
                if(condition){
                    currentWay = new Way(e.getX(), e.getY(), e.getX(), e.getY());
                    board.getWays().add(currentWay);
                    menu.getModeLabel().setText("Mode: House");
                    menu.getModeLabel().setForeground(Color.BLACK);
                }
            default:
                break;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (menu.getMode()==2){
            int x = e.getX();
            int y = e.getY();
            if (startingComponent == 1){
                for (Tree treeTemp : board.getTrees()) {
                    if (treeTemp.isMouseOn(x, y)) {
                        return;
                    }
                }
            }
            else {
                for (House houseTemp : board.getHouses()) {
                    if (houseTemp.isMouseOn(x, y)) {
                        return;
                    }
                }
            }
            board.getWays().remove(board.getWays().size()-1);
            board.paintComponent(board.getGraphics());
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (menu.getMode() == 2 && condition) {
            currentWay.setX2(e.getX());
            currentWay.setY2(e.getY());
            board.paintComponent(board.getGraphics());
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
