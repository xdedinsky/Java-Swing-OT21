package sk.stuba.fei.uim.oop.logic;

import sk.stuba.fei.uim.oop.window.myMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class myActionListener implements ActionListener {

    private myMenu menu;

    public myActionListener(myMenu menu) {
        this.menu = menu;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Tree":
                menu.setMode(0);
                menu.getModeLabel().setText("Mode: Tree");
                menu.getModeLabel().setForeground(menu.getColors().get(menu.getColor()%3));
                break;
            case "House":
                menu.setMode(1);
                menu.getModeLabel().setText("Mode: House");
                menu.getModeLabel().setForeground(menu.getColors().get(menu.getColor()%3));
                break;
            case "Way":
                menu.setMode(2);
                menu.getModeLabel().setText("Mode: Way");
                menu.getModeLabel().setForeground(menu.getColors().get(menu.getColor()%3));
                break;
        }
    }
}
