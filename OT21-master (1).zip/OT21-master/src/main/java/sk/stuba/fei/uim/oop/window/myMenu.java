package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.logic.myActionListener;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class myMenu {
    private static final String  TREE_BUTTON = "Tree";
    private static final String HOUSE_BUTTON = "House";
    private static final String  WAY_BUTTON = "Way";
    @Getter
    @Setter
    private JLabel modeLabel;
    @Getter
    @Setter
    private ArrayList<Color> colors;
    @Getter
    @Setter
    private int mode;
    @Getter
    @Setter
    private int color;

    public myMenu(JFrame frame) {
        colors = new ArrayList<>();
        colors.add(Color.GREEN);
        colors.add(Color.RED);
        colors.add(Color.BLUE);
        color = 0;
        mode = 0;

        JPanel panel = new JPanel();
        JButton treeButton = new JButton(TREE_BUTTON);
        JButton houseButton = new JButton(HOUSE_BUTTON);
        JButton wayButton = new JButton(WAY_BUTTON);

        myActionListener listener = new myActionListener(this);
        treeButton.addActionListener(listener);
        houseButton.addActionListener(listener);
        wayButton.addActionListener(listener);

        modeLabel = new JLabel("Mode: Tree");
        modeLabel.setForeground(Color.GREEN);
        panel.setLayout(new GridLayout(1,4));

        panel.add(treeButton);
        panel.add(houseButton);
        panel.add(wayButton);
        panel.add(modeLabel);

        frame.add(panel, BorderLayout.NORTH);
        frame.revalidate();
        frame.repaint();
    }
}
