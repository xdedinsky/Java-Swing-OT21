package sk.stuba.fei.uim.oop.stamps;

import java.awt.*;

public class Tree{
    private int x;
    private int y;
    private int width;
    private int height;
    private Color color;

    public Tree (int x, int y, int width, int height, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
    }

    public void paint(Graphics g) {
        g.setColor(color);
        g.fillRect(x+width/4, y+height/4, width/2, height/2);
        g.fillOval(x, y, width, height/2);
    }

    public boolean isMouseOn(int x, int y) {
        return x >= this.x && x <= this.x + width && y >= this.y && y <= this.y + height;
    }
}
