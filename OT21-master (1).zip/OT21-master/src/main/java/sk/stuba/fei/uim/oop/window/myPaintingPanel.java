package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.logic.myMouseListener;
import sk.stuba.fei.uim.oop.stamps.House;
import sk.stuba.fei.uim.oop.stamps.Tree;
import sk.stuba.fei.uim.oop.stamps.Way;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


public class myPaintingPanel extends JPanel {
    myMenu menu;
    @Getter @Setter
    ArrayList<Tree> trees;
    @Getter @Setter
    ArrayList<House> houses;
    @Getter @Setter
    ArrayList<Way> ways;
    public myPaintingPanel(myMenu menu, JFrame frame) {
        this.menu = menu;
        this.setSize(700,700);
        this.setVisible(true);
        this.setOpaque(true);
        this.setBackground(Color.GRAY);
        frame.add(this);
        frame.revalidate();
        frame.repaint();
        new myMouseListener(this, menu);
        trees = new ArrayList<>();
        houses = new ArrayList<>();
        ways = new ArrayList<>();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Tree tree:trees){
            tree.paint(g);
            this.revalidate();
            this.repaint();
        }
        for (House house:houses){
            house.paint(g);
            this.revalidate();
            this.repaint();
        }
        for (Way way:ways){
            way.paint(g);
            this.revalidate();
            this.repaint();
        }
    }
}
