package sk.stuba.fei.uim.oop;

import sk.stuba.fei.uim.oop.window.myFrame;

public class ExamOT {
    public static void main(String[] args) {
        myFrame frame = new myFrame();
    }
}
