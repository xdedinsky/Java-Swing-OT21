package sk.stuba.fei.uim.oop.stamps;

import lombok.Getter;
import lombok.Setter;

import java.awt.*;

public class Way {
    private int x;
    private int y;
    @Getter
    @Setter
    private int x2,y2;

    public Way (int x, int y, int x2, int y2) {
        this.x = x;
        this.y = y;
        this.x2 = x2;
        this.y2= y2;
    }

    public void paint(Graphics g) {
        g.setColor(Color.BLACK);
        g.drawLine(x,y,x2,y2);
    }

}
