package sk.stuba.fei.uim.oop.stamps;

import java.awt.*;

public class House {
    private int x;
    private int y;
    private int width;
    private int height;
    private Color color;

    public House (int x, int y, int width, int height, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
    }

    public void paint(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
        g.fillPolygon(new int[]{x, x + width / 2, x + width}, new int[]{y, y - height, y}, 3);
    }

    public boolean isMouseOn(int x, int y) {
        return x >= this.x && x <= this.x + width && y >= this.y && y <= this.y + height;
    }
}
